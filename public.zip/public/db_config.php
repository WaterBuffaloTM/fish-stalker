<?php
// Database configuration
$host = 'localhost';     // Hostinger database host
$dbname = 'u523883027_fish_stalker_d';  // Your Hostinger database name
$username = 'u523883027_fish_stalker_d';  // Your Hostinger database username
$password = 'CapBuff1999!';  // Your Hostinger database password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}
?> 